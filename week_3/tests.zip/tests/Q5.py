test = {   'name': 'Q5',
    'points': 0,
    'suites': [   {   'cases': [   {'code': '>>> # TEST\n>>> (((r <0) & (napis == "Wartość promienia nie może być ujemna!")) | (r>0)) == True\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> # TEST\n>>> ((Pole == pi*r*r) & (Obwod == 2*pi*r)) == True\n...  \nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
