test = {   'name': 'Q7',
    'points': 0.5,
    'suites': [   {   'cases': [   {   'code': '>>> # TEST\n'
                                               '>>> ((stawka_1_3 == 40 ) & (stawka_1_3 == 40 ) & (stawka_4_8 == 50 ) &(stawka_liceum == 70 ) & (stawka_matura == 80 ) & (N_1_godz_1_3 == 30 ) & '
                                               '(N_2_godz_1_3 == 15 ) & (N_2_godz_4_8 == 30 ) & (N_3_godz_matura == 50 ) & (N_4_godz_1_3 == 13 ) & (N_4_godz_4_8 == 13 ) & (N_4_godz_liceum == 13 ) & '
                                               '(N_4_godz_matura == 13 )) == True\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> # TEST\n>>> ( (zarobek_N_4 == 3120) & (zarobek_N_3 == 4000 ) & ( zarobek_N_2 == 2100 ) & (zarobek_N_1 == 1200 )) == True\nTrue',
                                       'hidden': False,
                                       'locked': False},
                                   {'code': '>>> # TEST\n>>> srednia_na_nauczyciela == 56.75\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> # TEST\n>>> srednie_wynagrodzenie == 2605.0\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> # TEST\n>>> zysk_firmy == profit_z_godziny * suma_godzin\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
