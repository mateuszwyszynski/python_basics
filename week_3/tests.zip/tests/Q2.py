test = {   'name': 'Q2',
    'points': 0.5,
    'suites': [   {   'cases': [   {   'code': '>>> assert sprawdz_znak(3) == "Liczba 3 jest dodatnia"\n'
                                               '>>> assert sprawdz_znak(11) == "Liczba 11 jest dodatnia"\n'
                                               '>>> assert sprawdz_znak(-7) == "Liczba -7 jest ujemna"\n'
                                               '>>> assert sprawdz_znak(-5) == "Liczba -5 jest ujemna"\n'
                                               '>>> assert sprawdz_znak(0) == "Podana liczba to zero"\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
