test = {   'name': 'Q2',
    'points': 0.0,
    'suites': [   {   'cases': [   {'code': '>>> # TEST\n>>> isinstance(y, int)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> # TEST\n>>> 9 < y < 11\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> # TEST\n>>> y == 10\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
