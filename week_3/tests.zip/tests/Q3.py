test = {   'name': 'Q3',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': ">>> assert platnosc_karta(300, 500, 400) == 'Platnosc zaakceptowana.'\n"
                                               ">>> assert platnosc_karta(30, 55, 40) == 'Platnosc zaakceptowana.'\n"
                                               ">>> assert platnosc_karta(300, 200, 400) == 'Brak srodkow.'\n"
                                               ">>> assert platnosc_karta(30, 10, 200) == 'Brak srodkow.'\n"
                                               ">>> assert platnosc_karta(300, 500, 200) == 'Przekroczono dzienny limit transakcji.'\n"
                                               ">>> assert platnosc_karta(15, 500, 10) == 'Przekroczono dzienny limit transakcji.'\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
