test = {   'name': 'Q3',
    'points': 0.0,
    'suites': [   {   'cases': [   {'code': '>>> # TEST\n>>> isinstance(z, int)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> # TEST\n>>> 95 < z < 97\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> # TEST\n>>> z == 96\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
