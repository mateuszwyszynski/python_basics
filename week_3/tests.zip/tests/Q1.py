test = {   'name': 'Q1',
    'points': 0.5,
    'suites': [   {   'cases': [   {   'code': ">>> assert system_platnosci(100.0, 200, 50) == 'Platnosc zaakceptowana.'\n"
                                               ">>> assert system_platnosci(200.0, 300, 400) == 'Platnosc zaakceptowana. Twoj kredyt wynosi 200.0 PLN.'\n"
                                               ">>> assert system_platnosci(200.0, 100, 250) == 'Platnosc zaakceptowana. Twoj kredyt wynosi 50.0 PLN.'\n"
                                               ">>> assert system_platnosci(200.0, 300, 600) == 'Platnosc odrzucona.'\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
