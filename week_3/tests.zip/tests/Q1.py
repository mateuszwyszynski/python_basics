test = {   'name': 'Q1',
    'points': 0.0,
    'suites': [   {   'cases': [   {'code': '>>> # TEST\n>>> isinstance(slowo, str)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> # TEST\n>>> slowo == "Hello, World!"\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
