test = {   'name': 'Q6',
    'points': 0.0,
    'suites': [   {   'cases': [   {'code': '>>> # TEST\n>>> ((wyn_n1 == 1350.0) & (wyn_n2 == 2737.5) & (wyn_n3 == 2080)) == True\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> # TEST\n>>> srednia_na_nauczyciela==10.0\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> srednie_wynagrodzenie == 562.5\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
