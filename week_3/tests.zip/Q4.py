test = {   'name': 'Q4',
    'points': 0.0,
    'suites': [   {   'cases': [   {'code': '>>> # TEST\n>>> isinstance(x, float)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> # TEST\n>>> 2 < x < 4\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> # TEST\n>>> x == 3.0\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
