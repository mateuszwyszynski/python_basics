test = {'name': 'Q1', 'points': 0.5, 'suites': [{'cases': [{'code': '>>> z == 113 * 17\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
