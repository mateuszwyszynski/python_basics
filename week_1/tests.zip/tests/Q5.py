test = {   'name': 'Q5',
    'points': 0.5,
    'suites': [   {   'cases': [   {'code': '>>> x = 7\n>>> assert reszta(x) == 2\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> x = 13\n>>> assert reszta(x) == 3\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> x = 64\n>>> assert reszta(x) == 4\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
