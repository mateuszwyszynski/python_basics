test = {   'name': 'Q2',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> square(1)==1\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> square(0.5)==(0.25)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> square(2)==4\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
