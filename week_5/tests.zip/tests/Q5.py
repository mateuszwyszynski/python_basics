test = {   'name': 'Q5',
    'points': 0,
    'suites': [   {   'cases': [   {'code': '>>> assert(Catalan(1000000,0)==0)\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert(Catalan(10,1)==7)\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert(Catalan(1000000,1)==10)\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
