test = {   'name': 'Q5',
    'points': 0,
    'suites': [   {   'cases': [   {'code': '>>> assert(catalan(1000000)==10)\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert(catalan(10)==7)\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert(catalan(1000000)==10)\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
