test = {   'name': 'Q1',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> assert Maks_w_zbiorze([32, 15, 26, 78, 15, 96, 99, 1, 17, 63, 24, 19, 65, 68, 2]) == 99\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert Maks_w_zbiorze([32, 15, 26, 78, 15, 96, 9, 1, 17, 63, 24, 19, 65, 68, 2]) == 96\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert Maks_w_zbiorze([32, 15, 26, 78, 15, 6, 9, 1, 17, 63, 24, 19, 65, 68, 2]) == 78\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
