test = {   'name': 'Q3',
    'points': 0.5,
    'suites': [   {   'cases': [   {'code': '>>> assert(silnia(0) == 1)\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert(silnia(5) == 120)\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert(silnia(8) == 40320)\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
