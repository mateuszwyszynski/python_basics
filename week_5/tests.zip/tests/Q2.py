test = {   'name': 'Q2',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> assert Min_w_zbiorze([32, 15, 26, 78, 15, 96, 99, 1, 17, 63, 24, 19, 65, 68, 2]) == 1\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert Min_w_zbiorze([32, 15, 26, 78, 15, 96, 9, 10, 17, 63, 24, 19, 65, 68, 2]) == 2\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert Min_w_zbiorze([-32, -15, -26, -78, -15, -96, -99, -1, -17, -63, -204, -19]) == -204\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
