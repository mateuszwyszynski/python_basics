test = {   'name': 'Q2',
    'points': 0.5,
    'suites': [   {   'cases': [   {   'code': '>>> assert find_keys({\n'
                                               "...   'Theodore': 19,\n"
                                               "...   'Roxanne': 20,\n"
                                               "...   'Mathew': 21,\n"
                                               "...   'Betty': 22 }) == ['Betty']\n"
                                               '>>> \n'
                                               '>>> assert find_keys({\n'
                                               "...   'Theodore': 22,\n"
                                               "...   'Roxanne': 22,\n"
                                               "...   'Mathew': 22,\n"
                                               "...   'Betty': 22 }) == ['Theodore', 'Roxanne', 'Mathew', 'Betty']\n"
                                               '>>> \n'
                                               '>>> assert find_keys({\n'
                                               "...   'Theodore': 21,\n"
                                               "...   'Roxanne': 21,\n"
                                               "...   'Mathew': 21,\n"
                                               "...   'Betty': 21 }) == []\n"
                                               '>>> \n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
