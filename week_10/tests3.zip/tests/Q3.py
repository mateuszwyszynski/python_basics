test = {   'name': 'Q3',
    'points': 0.5,
    'suites': [   {   'cases': [   {   'code': ">>> assert similiar_numbers([1,2,3,4,5,6,7]) == {'1': [1, 5], '2': [2, 6], '3': [3, 7]}\n"
                                               ">>> assert similiar_numbers([5,6,7,8,9,12,654]) == {'1': [5, 9], '2': [6, 654], '3': [7]}\n"
                                               ">>> assert similiar_numbers([55,6,76,8,9,42,654,56788]) == {'1': [9], '2': [6, 42, 654], '3': [55]}\n"
                                               ">>> assert similiar_numbers([865,76547,53,432543,765,8769765,43,54]) == {'1': [865, 53, 765, 8769765], '2': [54], '3': [76547, 432543, 43]}\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
