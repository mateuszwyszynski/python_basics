test = {   'name': 'Q1',
    'points': 0,
    'suites': [{'cases': [{'code': '>>> assert pole_trapezu(4,4,5) == 20\n', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
