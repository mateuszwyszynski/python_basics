test = {   'name': 'Q2',
    'points': 0,
    'suites': [   {   'cases': [   {'code': ">>> assert parzystosc(2).replace('.','').lower() == 'liczba jest parzysta'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert parzystosc(5).replace('.','').lower() == 'liczba jest nieparzysta'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
