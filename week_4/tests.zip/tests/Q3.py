test = {   'name': 'Q3',
    'points': 0,
    'suites': [   {   'cases': [   {'code': ">>> assert trojkat(1,2,3) == 'Nie mozna zbudowac trojkata'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert trojkat(5,5,8) == 'Mozna zbudowac trojkat'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
