test = {   'name': 'Q3',
    'points': 0,
    'suites': [   {   'cases': [   {   'code': ">>> assert trojkat(1,2,3).replace('.','').lower() == 'nie mozna zbudowac trojkata'\n"
                                               ">>> assert trojkat(2,1,3).replace('.','').lower() == 'nie mozna zbudowac trojkata'\n"
                                               ">>> assert trojkat(3,2,1).replace('.','').lower() == 'nie mozna zbudowac trojkata'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {'code': ">>> assert trojkat(5,5,8).replace('.','').lower() == 'mozna zbudowac trojkat'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
