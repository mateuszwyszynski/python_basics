test = {   'name': 'Q5',
    'points': 0,
    'suites': [   {   'cases': [{'code': '>>> assert modul(-3) == 3\n', 'hidden': False, 'locked': False}, {'code': '>>> assert modul(5) == 5\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
