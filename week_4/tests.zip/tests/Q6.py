test = {   'name': 'Q6',
    'points': 0.5,
    'suites': [   {   'cases': [{'code': ">>> assert termometr(32, 'c') == 0\n", 'hidden': False, 'locked': False}, {'code': ">>> assert termometr(5, 'f') == 41\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
