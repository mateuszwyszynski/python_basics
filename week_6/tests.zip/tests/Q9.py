test = {   'name': 'Q9',
    'points': 0,
    'suites': [   {   'cases': [   {   'code': ">>> assert age_from_string_ext('Mateusz,Wiśniewski,24') == 24\n"
                                               ">>> assert age_from_string_ext('Mateusz, Wiśniewski, 24') == 24\n"
                                               ">>> assert age_from_string_ext(5).lower().replace('.','').replace(' ','') == 'Parametr powinien byc typu str'.lower().replace(' ','')\n"
                                               ">>> assert age_from_string_ext('Wiśniewski,24').lower().replace('.','').replace(' "
                                               '\',\'\').replace(\',\',\'\').replace(\'"\',\'\').replace("\'",\'\') == \'Lancuch powinien byc postaci '
                                               '"Imie,Nazwisko,Wiek"\'.lower().replace(\'"\',\'\').replace(\' \',\'\').replace(\',\',\'\')\n'
                                               '>>> assert age_from_string_ext(\'test\').lower().replace(\'.\',\'\').replace(\' \',\'\').replace(\',\',\'\').replace(\'"\',\'\').replace("\'",\'\') == '
                                               '\'Lancuch powinien byc postaci "Imie,Nazwisko,Wiek"\'.lower().replace(\'"\',\'\').replace(\' \',\'\').replace(\',\',\'\')\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
