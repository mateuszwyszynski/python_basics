test = {   'name': 'Q3',
    'points': 0,
    'suites': [   {   'cases': [   {   'code': ">>> assert all(element in information_about_patron.lower() for element in ['ryszard', 'lazarski', 'warszawa', '74', 'ekonomista'])\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
