test = {   'name': 'Q7',
    'points': 0.5,
    'suites': [   {   'cases': [{'code': ">>> assert age_from_string('Mateusz,Wiśniewski,24') == 24\n>>> assert age_from_string('słowo, słowo2,24') == 24\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
