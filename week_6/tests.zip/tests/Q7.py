test = {   'name': 'Q7',
    'points': 0.5,
    'suites': [   {   'cases': [   {   'code': ">>> assert age_from_string('Mateusz,Wiśniewski,24') == 24\n"
                                               ">>> assert age_from_string('Mateusz, Wiśniewski, 24') == 24\n"
                                               ">>> assert age_from_string(5).lower().replace('.','').replace(' ','') == 'Parametr powinien byc typu str'.lower().replace(' ','')\n"
                                               ">>> assert age_from_string('Wiśniewski,24').lower().replace('.','').replace(' "
                                               '\',\'\').replace(\',\',\'\').replace(\'"\',\'\').replace("\'",\'\') == \'Lancuch powinien byc postaci '
                                               '"Imie,Nazwisko,Wiek"\'.lower().replace(\'"\',\'\').replace(\' \',\'\').replace(\',\',\'\')\n'
                                               '>>> assert age_from_string(\'test\').lower().replace(\'.\',\'\').replace(\' \',\'\').replace(\',\',\'\').replace(\'"\',\'\').replace("\'",\'\') == '
                                               '\'Lancuch powinien byc postaci "Imie,Nazwisko,Wiek"\'.lower().replace(\'"\',\'\').replace(\' \',\'\').replace(\',\',\'\')\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
