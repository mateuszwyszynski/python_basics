test = {   'name': 'Q8',
    'points': 1.5,
    'suites': [   {   'cases': [   {   'code': ">>> assert all(element in pesel_interpretation('37102582725').lower() for element in ['37', '10', '25', 'kobieta'])\n"
                                               ">>> assert 'PESEL powinien skladac sie z 11 cyfr'.replace(' ','').lower() in pesel_interpretation('3710258272').lower().replace(' ','')\n"
                                               ">>> assert 'PESEL powinien skladac sie z 11 cyfr'.replace(' ','').lower() in pesel_interpretation('3710258272a').lower().replace(' ','')\n"
                                               ">>> assert 'PESEL niepoprawny'.replace(' ','').lower() in pesel_interpretation('37102582726').replace(' ','').lower()\n"
                                               ">>> assert 'Miesiac niepoprawny'.lower().replace(' ','') in pesel_interpretation('37132582728').lower().replace(' ','')\n"
                                               ">>> assert 'Dzien niepoprawny'.lower().replace(' ','') in pesel_interpretation('37103482727').lower().replace(' ','')\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
