test = {   'name': 'Q4',
    'points': 0,
    'suites': [   {   'cases': [   {   'code': ">>> assert (length('') == 0)\n>>> assert (length('test') == len('test'))\n>>> assert (length('interstellar') == len('interstellar'))\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
