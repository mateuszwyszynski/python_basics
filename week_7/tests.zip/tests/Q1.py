test = {   'name': 'Q1',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> assert(suma_wierszy(pd.Series([1,1,1,1,1,1,1,1,1,1]))==3)\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert(suma_wierszy(pd.Series([0,0,0,0,0,0,0,0,0,0]))==0)\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert(suma_wierszy(pd.Series([-4,-3,-2,-1,0,1,2,3,4]))==0)\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
