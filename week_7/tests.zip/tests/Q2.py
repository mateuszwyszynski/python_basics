test = {   'name': 'Q2',
    'points': 1,
    'suites': [   {   'cases': [   {'code': ">>> assert(nowy_df(pd.Series([1,2,3,4,5,6,7,8,9,10]),0)['kol'][0]==1)\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert(nowy_df(pd.Series([-4,-3,-2,-1,0,1,2,3,4]),0)['kol'][0]==-4)\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert(nowy_df(pd.Series([-40,-31,-20,-10,50,10,29,34,46]),0.5)['kol5'][6]==5.385164807134504)\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
