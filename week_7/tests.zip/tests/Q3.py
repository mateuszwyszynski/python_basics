test = {   'name': 'Q3',
    'points': 0.5,
    'suites': [   {   'cases': [   {'code': '>>> assert(liczba_komorek(pd.DataFrame(0, index=range(3), columns=range(8))) == 3*8)\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert(liczba_komorek(pd.DataFrame(0, index=range(10), columns=range(5))) == 10*5)\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
