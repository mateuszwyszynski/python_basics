test = {   'name': 'Q4',
    'points': 2,
    'suites': [   {   'cases': [   {'code': ">>> assert(panstwo_najnizej(df_test, 'kolumna1') == 'Canada')\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert(panstwo_najnizej(df_test, 'kolumna2') == 'Germany')\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
