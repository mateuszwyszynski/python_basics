test = {   'name': 'Q4.d',
    'points': 0.5,
    'suites': [   {   'cases': [   {   'code': ">>> assert all(x in inspect.getsource(unique_number) for x in ['list_with_strings_cleaning', 'list_with_strings_splitting', "
                                               "'list_with_words_unique'])\n"
                                               '>>> assert unique_number(mickiewicz) == 283\n'
                                               '>>> assert unique_number(slowacki) == 289\n',
                                       'failure_message': 'W szkielecie funkcji wywolaj kolejne, wczesniej zdefiniowane funkcje, przyjmujac za ich parametr argument funkcji unique_number. Zapisuj wyniki ich dzialania jako kolejne zmienne, czyli jak najpierw wyczyscisz wszystkie wersy, zapisz ten wynik np. jako zmienna o nazwie list_cleaned, nastepnie wykorzystaj te zmienna, dzielac kazdy wiersz na osobne slowa itd.',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': 'Congrats to Slowacki and you!'}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
