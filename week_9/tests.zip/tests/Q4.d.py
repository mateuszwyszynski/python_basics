test = {   'name': 'Q4.d',
    'points': 0.5,
    'suites': [   {   'cases': [   {   'code': ">>> assert all(x in inspect.getsource(unique_number) for x in ['list_with_strings_cleaning', 'list_with_strings_splitting', "
                                               "'list_with_words_unique'])\n"
                                               '>>> assert unique_number(mickiewicz) == 283\n'
                                               '>>> assert unique_number(slowacki) == 289\n',
                                       'failure_message': 'Try again!',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': 'Congrats to Slowacki and you!'}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
