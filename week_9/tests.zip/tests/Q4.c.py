test = {   'name': 'Q4.c',
    'points': 0.5,
    'suites': [   {   'cases': [   {   'code': ">>> assert list_with_words_unique(['bez', 'serc', 'bez', 'ducha', 'to', 'szkieletów', 'ludy', 'i', 'wonne', 'płoną', 'kadzidła']) == 10\n"
                                               ">>> assert list_with_words_unique(['słowo', 'słowo', 'słowo']) == 1\n"
                                               ">>> assert list_with_words_unique(['słowo1', 'słowo1', 'słowo2', 'słowo3', 'słowo3', 'słowo3']) == 3\n",
                                       'failure_message': 'Stworz pusta liste i przechodzac przez elementy listy bedacej parametrem funkcji dodawaj te elementy do lokalnie zdefiniowanej pustej listy tylko wtedy, jezeli jeszcze w tej liscie sie nie znajduja.',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': 'Congrats!'}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
