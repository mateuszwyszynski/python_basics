test = {   'name': 'Q4.b',
    'points': 0.5,
    'suites': [   {   'cases': [   {   'code': ">>> assert list_with_strings_splitting(['bez serc bez ducha to szkieletów ludy', 'i wonne płoną kadzidła']) == ['bez', 'serc', 'bez', 'ducha', 'to', "
                                               "'szkieletów', 'ludy', 'i', 'wonne', 'płoną', 'kadzidła']\n"
                                               ">>> assert list_with_strings_splitting(['bez serc bez ducha to szkieletów ludy', 'młodości dodaj mi skrzydła', 'niech nad martwym wzlecę światem', 'w "
                                               "rajską dziedzinę ułudy']) == ['bez', 'serc', 'bez', 'ducha', 'to', 'szkieletów', 'ludy', 'młodości', 'dodaj', 'mi', 'skrzydła', 'niech', 'nad', "
                                               "'martwym', 'wzlecę', 'światem', 'w', 'rajską', 'dziedzinę', 'ułudy']\n"
                                               ">>> assert list_with_strings_splitting(['witaj wolności aniele', 'nad martwym wzniesiony światem', 'oto w ojczyzny kościele', 'ołtarze wieńczone "
                                               "kwiatem']) == ['witaj', 'wolności', 'aniele', 'nad', 'martwym', 'wzniesiony', 'światem', 'oto', 'w', 'ojczyzny', 'kościele', 'ołtarze', 'wieńczone', "
                                               "'kwiatem']\n",
                                       'failure_message': 'Try again!',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': 'Congrats!'}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
