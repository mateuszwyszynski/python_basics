test = {   'name': 'Q4.a',
    'points': 0.5,
    'suites': [   {   'cases': [   {   'code': ">>> assert list_with_strings_cleaning(['Bez serc, bez ducha, to szkieletow ludy;\\n', 'I wonne plona kadzidla!\\n']) == ['bez serc bez ducha to "
                                               "szkieletow ludy', 'i wonne plona kadzidla']\n"
                                               '>>> assert list_with_strings_cleaning([\':;!?.,\\n"-*Slowa\', \'bez znakow specjalnych\']) == [\'slowa\', \'bez znakow specjalnych\']\n',
                                       'failure_message': 'Przesledz raz jeszcze dokladnie rozwiazanie zadania z sekcji Metody obiektow bedacych listami Przyklad uzycia i odpowiednio je przeformuluj. Moze sie takze przydac metoda .lower().',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': 'Congrats!'}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
