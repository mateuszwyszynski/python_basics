test = {   'name': 'Q1',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': ">>> assert (iloczyn_kolumn(df, 'kolumna1', 'kolumna2') == pd.Series([-99,-96,-91,-84,-75,-64,-51,-36,-19,0])).all()\n"
                                               ">>> assert (iloczyn_kolumn(df, 'kolumna', 'kolumna3') == pd.Series([10,40,90,160,250,360,490,640,810,1000])).all()\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
