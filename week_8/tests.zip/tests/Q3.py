test = {   'name': 'Q3',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> assert mnozenie_po_indeksach(df,3,2,6,0) == -42\n'
                                               '>>> assert mnozenie_po_indeksach(df,0,0,0,1) == 11\n'
                                               '>>> assert mnozenie_po_indeksach(df,8,4,4,3) == 45.0\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
