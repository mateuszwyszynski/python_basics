test = {   'name': 'Q2',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> assert podwojna_srednia_kolumny(df, 'kolumna1') == 31.0\n"
                                               ">>> assert podwojna_srednia_kolumny(df, 'kolumna2') == -9.0\n"
                                               ">>> assert podwojna_srednia_kolumny(df, 'kolumna3') == 110.0\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
