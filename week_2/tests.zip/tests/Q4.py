test = {   'name': 'Q4',
    'points': 0.5,
    'suites': [   {   'cases': [{'code': '>>> x == (15 - 13) ** 2 + 15 / 3 - (63 / 7) ** 0.5 *2 # SOLUTION\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
