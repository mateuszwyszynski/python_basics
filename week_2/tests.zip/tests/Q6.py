test = {   'name': 'Q6',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> assert s_poz_a == 40\n'
                                               '>>> assert s_poz_b == 50 \n'
                                               '>>> assert s_poz_c == 70 \n'
                                               '>>> \n'
                                               '>>> assert n1_h_poz_a == 30\n'
                                               '>>> assert n1_h_poz_b == 0\n'
                                               '>>> assert n1_h_poz_c == 0 \n'
                                               '>>> \n'
                                               '>>> assert n2_h_poz_a == 0 \n'
                                               '>>> assert n2_h_poz_b == 30 \n'
                                               '>>> assert n2_h_poz_c == 15 \n'
                                               '>>> \n'
                                               '>>> assert n3_h_poz_a == 13 \n'
                                               '>>> assert n3_h_poz_b == 13 \n'
                                               '>>> assert n3_h_poz_c == 13\n'
                                               '>>> \n'
                                               '>>> assert wyn_n1 == n1_h_poz_a * s_poz_a + n1_h_poz_b * s_poz_b + n1_h_poz_c * s_poz_c\n'
                                               '>>> assert wyn_n2 == n2_h_poz_a * s_poz_a + n2_h_poz_b * s_poz_b + n2_h_poz_c * s_poz_c \n'
                                               '>>> assert wyn_n3 == n3_h_poz_a * s_poz_a + n3_h_poz_b * s_poz_b + n3_h_poz_c * s_poz_c \n'
                                               '>>> \n'
                                               '>>> assert total_h_n2 == n2_h_poz_a + n2_h_poz_b + n2_h_poz_c \n'
                                               '>>> assert total_h_n3 == n3_h_poz_a + n3_h_poz_b + n3_h_poz_c \n'
                                               '>>> \n'
                                               '>>> assert mean_h == (total_h_n1 + total_h_n2 + total_h_n3)/3 \n'
                                               '>>> \n'
                                               '>>> assert mean_wyn == (wyn_n1 + wyn_n2 + wyn_n3)/3\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
