test = {   'name': 'Q1',
    'points': 1.5,
    'suites': [   {   'cases': [   {   'code': ">>> assert suma_wyslana([('ewa', 200), ('maurycy', -100), ('adam', 500)]) == 600\n"
                                               ">>> assert suma_wyslana([('kasia', 100), ('maja', -100)]) == 0\n"
                                               ">>> assert suma_wyslana([('maciek', -1000), ('kuba', 200), ('adam', 500), ('krystian', -400)]) == -700\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
